package com.blockChain.Cipher.bswabe;

import it.unisa.dia.gas.jpbc.Element;

public class BswabeElementBoolean {
	/*
	 * This class is defined for some classes who return both boolean and
	 * Element.
	 */
	public Element e;
	public boolean b;
}
