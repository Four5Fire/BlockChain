package com.blockChain.entity;

import lombok.Data;

@Data
public class UserVO {
    private String username;
    private String userPic;

}
